<div class="content">
    <div class="row" style="padding: 100px 10px 10px 20%;">
        <div class="col-md-8">
            <h1 style="color:#003399; font-family:TH Sarabun New; font-weight: 900; font-size: 80px;">คิวอาร์โค้ดของฉัน</h1>
        </div>
        <div class="col-md-4">

            <button class="btn btn-primary btn-round" style=" width: 145px; background-color: #F5F5F5 ; border: none;" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                <h1 style="font-weight: 900; color:#003399 ; font-size: 50px; font-family:TH Sarabun New; height: 40; width: 50px;" id="button-folder">+ สร้าง</h1>
            </button>
        </div>