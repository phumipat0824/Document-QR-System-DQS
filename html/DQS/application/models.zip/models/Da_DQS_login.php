<?php
defined('BASEPATH') OR exit('No direct script access allowed');

include_once 'DQS_model.php';

class Da_DQS_login extends DQS_model {
    

	public function __construct()
	{
        parent::__construct();
	}


}